<?php
session_start();

// Check if user is authorized
if (!isset($_SESSION['lab_id'])) {
    die("Unauthorized access. Please log in.");
}

// Database connection
$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch data for the logged-in lab_id
$role = strtolower(trim($_SESSION['role']));
$lab_id = trim($_SESSION['lab_id']);
$data = [];

if (in_array($role, ['lab assistant', 'lab faculty incharge'])) {
    $sql = "SELECT sr_no, lab_id, name_of_the_item, date, last_maintenance, maintenance_due, service_provider, disposal_status 
            FROM register WHERE lab_id = ? AND (disposal_status IS NULL OR disposal_status != 'disposed completely')";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log('Query preparation failed: ' . $conn->error);
        die("Query preparation failed: " . $conn->error);
    }
    $stmt->bind_param("s", $lab_id);
} else {
    $sql = "SELECT sr_no, lab_id, name_of_the_item, date, last_maintenance, maintenance_due, service_provider, disposal_status 
            FROM register WHERE disposal_status IS NULL OR disposal_status != 'disposed completely'";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log('Query preparation failed: ' . $conn->error);
        die("Query preparation failed: " . $conn->error);
    }
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DAMS - Maintenance</title>
    <link rel="stylesheet" href="./maintenance.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <script>
        const userRole = '<?php echo isset($_SESSION['role']) ? strtolower(trim($_SESSION['role'])) : ''; ?>';
        window.maintenanceData = <?php echo isset($data) && is_array($data) ? json_encode($data) : '[]'; ?>;
        console.log('Initial maintenanceData:', window.maintenanceData);
    </script>
    <input type="hidden" id="labIdInput" value="<?php echo isset($_SESSION['lab_id']) ? htmlspecialchars($_SESSION['lab_id']) : ''; ?>">
</head>

<body>
    <div id="dashboard-container" class="d-flex">

        <div id="sidebar" class="d-flex flex-column   py-3">
            <h4 class="dams ps-4 pt-4 mb-5"><b>DAMS</b></h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="lab_faculty_incharge.php" class="nav-link link-hover" id="dashboard-link"><i class="fas fa-home pe-2 ps-2"></i> Dashboard</a></li>
                <li><a href="../Inventory/category.php" class="nav-link link-hover" id="inventory-link"><i class="fas fa-box pe-2 ps-2"></i> Inventory</a></li>
                <li><a href="../forms/proc.html" class="nav-link link-hover" id="requisition-link"><i class="fas fa-file-alt pe-2 ps-2"></i> Procurement</a></li>
                <li><a href="../disposal/disposal.php" class="nav-link link-hover" id="condemnation-link"><i class="fas fa-exclamation-triangle pe-2 ps-2"></i> Codemnation</a></li>
                <li><a href="../maintenance/maintenance.php" class="nav-link link-hover" id="maintenance-link"><i class="fas fa-wrench pe-2 ps-2"></i> Maintenance</a></li>
                <li><a href="../Authetication/logout.php" class="nav-link link-hover"><i class="fas fa-sign-out-alt pe-2 ps-2"></i> Logout</a></li>
            </ul>
        </div>

        <!--  <div class="sidebar">
        <h2>DAMS</h2>
        <ul>
            <li><a href="../dashboard/dashboard.html">Dashboard</a></li>
            <li><a href="../inventory/inventory.html">Inventory</a></li>
            <li><a href="../procurement/procurement.html">Procurement</a></li>
            <li><a href="../disposal/disposal.php">Condemnation</a></li>
            <li><a href="../maintenance/maintenance.php" class="active">Maintenance</a></li>
            <li><a href="../student/student.html">Student Issues</a></li>
            <li><a href="../logout/logout.php">Logout</a></li>
        </ul>
    </div> -->

        <div id="main-content" class="container-fluid">
            <div class="row mynav d-flex">
                <nav class="navbar w-100 navbar-light bg-custom d-flex justify-content-between">
                    <span class="ms-3" id="menu-toggle"><i class="fas fa-bars"></i></span>
                    <input class="form-control w-50 ms-1" type="search" placeholder="Search assets...">
                    <div>
                        <i class="far fa-user"></i>
                        <span class="ms-1 me-3"><?php echo $_SESSION['name']; ?> (<?php echo $_SESSION['role']; ?>)</span>
                    </div>
                </nav>
            </div>
            <h1>Maintenance Table</h1>
            <div>
                <button id="sendDisposalRequest" style="display: none">Send Disposal Request</button>
                <button id="showAlerts">Show Alerts</button>
            </div>




            <table id="maintenanceTable">
                <thead>
                    <tr>
                        <?php if (in_array($role, ['lab assistant', 'lab faculty incharge', 'hod', 'admin'])) { ?>
                            <th><input type="checkbox" id="selectAll"></th>
                        <?php } ?>
                        <th>Lab ID</th>
                        <th>Item Name</th>
                        <th>Date</th>
                        <th>Last Maintenance</th>
                        <th>Maintenance Due</th>
                        <th>Service Provider</th>
                        <?php if (in_array($role, ['lab assistant', 'lab faculty incharge', 'hod', 'admin'])) { ?>
                            <th>Action</th>
                        <?php } ?>
                    </tr>
                </thead>
                <tbody id="maintenanceBody"></tbody>
            </table>

            <div id="alertsTable" style="display: none;">
                <h2>Maintenance Alerts</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Lab ID</th>
                            <th>Item Name</th>
                            <th>Date</th>
                            <th>Last Maintenance</th>
                            <th>Maintenance Due</th>
                            <th>Service Provider</th>
                            <?php if (in_array($role, ['lab assistant', 'lab faculty incharge', 'hod', 'admin'])) { ?>
                                <th>Action</th>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody id="alertsBody"></tbody>
                </table>
            </div>

            <div id="editModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">×</span>
                    <h2>Edit Maintenance Info</h2>
                    <form id="editForm">
                        <label>Serial Number: <input type="text" id="editSrNo" name="sr_no" readonly></label>
                        <label>Item Name: <input type="text" id="editItemId" name="item_name" readonly></label>
                        <label>Last Maintenance: <input type="date" id="editLastMaintenance" name="last_maintenance"></label>
                        <label>Maintenance Due: <input type="date" id="editMaintenanceDue" name="maintenance_due" readonly></label>
                        <label>Service Provider: <input type="text" id="editServiceProvider" name="service_provider"></label>
                        <button type="submit">Update</button>
                    </form>
                </div>
            </div>

            <div id="disposalReasonModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeDisposalModal()">×</span>
                    <h3>Enter Reason for Disposal</h3>
                    <textarea id="disposalReason" rows="4" cols="50" placeholder="Enter reason for disposal"></textarea>
                    <br>
                    <button id="submitDisposalReason">Submit</button>
                </div>
            </div>

        </div>
        <script src="maintenance.js"></script>
</body>

</html>