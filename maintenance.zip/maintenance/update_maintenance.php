<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['lab_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

$sr_no = $_POST['sr_no'] ?? '';
$last_maintenance = $_POST['last_maintenance'] ?? '';
$maintenance_due = $_POST['maintenance_due'] ?? '';
$service_provider = $_POST['service_provider'] ?? '';
$lab_id = $_SESSION['lab_id'];

if (empty($sr_no)) {
    echo json_encode(['status' => 'error', 'message' => 'Serial number is required']);
    exit;
}

$sql = "UPDATE register SET last_maintenance = ?, maintenance_due = ?, service_provider = ? WHERE sr_no = ? AND lab_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'Query preparation failed']);
    exit;
}

$stmt->bind_param("sssss", $last_maintenance, $maintenance_due, $service_provider, $sr_no, $lab_id);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>