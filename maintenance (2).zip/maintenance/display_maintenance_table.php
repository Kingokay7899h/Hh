<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['lab_id'])) {
    echo json_encode(["error" => "Unauthorized", "session" => $_SESSION]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

$lab_id = trim($_SESSION['lab_id']); // Remove extra spaces
$sql = "SELECT sr_no, lab_id, name_of_the_item, date, last_maintenance, maintenance_due, service_provider FROM register WHERE lab_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(["error" => "Query preparation failed"]);
    exit;
}

$stmt->bind_param("s", $lab_id);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$json = json_encode($data);
if ($json === false) {
    echo json_encode(["error" => "JSON encoding failed", "message" => json_last_error_msg()]);
} else {
    echo $json;
}

$stmt->close();
$conn->close();
?>