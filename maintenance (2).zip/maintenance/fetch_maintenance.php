<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['lab_id'])) {
    error_log('Unauthorized access in fetch_maintenance.php');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    error_log('Database connection failed: ' . $conn->connect_error);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

$role = strtolower(trim($_SESSION['role']));
$input = json_decode(file_get_contents('php://input'), true);
$lab_id = !empty($input['lab_id']) ? trim($input['lab_id']) : trim($_SESSION['lab_id']);
error_log('fetch_maintenance.php - Role: ' . $role . ', Input lab_id: ' . ($input['lab_id'] ?? 'none') . ', Session lab_id: ' . $_SESSION['lab_id']);

error_log('fetch_maintenance.php - Role: ' . $role . ', Lab ID: ' . $lab_id);

if (in_array($role, ['lab assistant', 'lab faculty incharge']) && empty($lab_id)) {
    error_log('Lab ID required for role: ' . $role);
    echo json_encode(['status' => 'error', 'message' => 'Lab ID required']);
    exit;
}

if (in_array($role, ['lab assistant', 'lab faculty incharge'])) {
    $sql = "SELECT sr_no, lab_id, name_of_the_item, date, last_maintenance, maintenance_due, service_provider, disposal_status 
            FROM register WHERE lab_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log('Query preparation failed: ' . $conn->error);
        echo json_encode(['status' => 'error', 'message' => 'Query preparation failed']);
        exit;
    }
    $stmt->bind_param("s", $lab_id);
} else {
    $sql = "SELECT sr_no, lab_id, name_of_the_item, date, last_maintenance, maintenance_due, service_provider, disposal_status 
            FROM register";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log('Query preparation failed: ' . $conn->error);
        echo json_encode(['status' => 'error', 'message' => 'Query preparation failed']);
        exit;
    }
}

if (!$stmt->execute()) {
    error_log('Query execution failed: ' . $stmt->error);
    echo json_encode(['status' => 'error', 'message' => 'Query execution failed']);
    exit;
}

$result = $stmt->get_result();
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode(['status' => 'success', 'data' => $data]);
