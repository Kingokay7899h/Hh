const allowedRoles = ['lab assistant', 'lab faculty incharge', 'hod', 'admin'];

document.addEventListener("DOMContentLoaded", function () {
    console.log('DOM loaded, userRole:', userRole);
    window.maintenanceData = window.maintenanceData || [];
    populateTable("maintenanceBody", window.maintenanceData, allowedRoles.includes(userRole));

    const selectAllCheckbox = document.getElementById("selectAll");
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener("change", function () {
            const checkboxes = document.querySelectorAll("#maintenanceBody input[type='checkbox']:not(:disabled)");
            console.log('Select all checkboxes:', checkboxes);
            checkboxes.forEach(cb => cb.checked = this.checked);
            toggleDisposalButton();
        });
    }

    document.getElementById("sendDisposalRequest").addEventListener("click", function () {
        const selectedItems = getSelectedItems();
        if (selectedItems.length > 0) {
            if (selectedItems.length === 1) {
                showDisposalReasonPopup(selectedItems);
            } else {
                localStorage.setItem('selectedItemsForDisposal', JSON.stringify(selectedItems));
                localStorage.setItem('disposalReason', '');
                window.location.href = 'condemnationForm.html';
            }
        } else {
            alert("Please select at least one item to send a disposal request.");
        }
    });

    document.getElementById("showAlerts").addEventListener("click", function () {
        const alertsTable = document.getElementById("alertsTable");
        const button = this;
        if (alertsTable.style.display === "block") {
            alertsTable.style.display = "none";
            button.textContent = "Show Alerts";
        } else {
            alertsTable.style.display = "block";
            button.textContent = "Hide Alerts";
            loadAlerts();
        }
    });

    document.getElementById("submitDisposalReason").addEventListener("click", function () {
        const reason = document.getElementById("disposalReason").value.trim();
        const selectedItems = getSelectedItems();
        if (!reason) {
            alert('Please enter a reason for disposal');
            return;
        }
        localStorage.setItem('selectedItemsForDisposal', JSON.stringify(selectedItems));
        localStorage.setItem('disposalReason', reason);
        closeDisposalModal();
        window.location.href = 'condemnationForm.html';
    });

    document.getElementById("editForm").addEventListener("submit", function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append("is_alert", document.getElementById("editModal").dataset.alert === "true");
        fetch("update_maintenance.php", {
            method: "POST",
            body: formData
        })
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                console.log('Update response:', data);
                if (data.status === "success") {
                    closeModal();
                    alert("Maintenance updated successfully");
                    // Fetch updated data and wait for completion
                    fetch("fetch_maintenance.php", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Cache-Control": "no-cache"
                        },
                        body: JSON.stringify(userRole === 'lab assistant' || userRole === 'lab faculty incharge' ? { lab_id: document.getElementById('labIdInput').value } : {})
                    })
                        .then(response => {
                            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                            return response.json();
                        })
                        .then(data => {
                            console.log('Fetch response:', data);
                            if (data.status === "success") {
                                window.maintenanceData = data.data || [];
                                console.log('Fetched maintenance data:', window.maintenanceData);
                                populateTable("maintenanceBody", window.maintenanceData, allowedRoles.includes(userRole));
                                // Update alerts table if visible
                                if (document.getElementById("alertsTable").style.display === "block") {
                                    const today = new Date();
                                    const overdueData = (window.maintenanceData || []).filter(item => {
                                        const dueDate = new Date(item.maintenance_due);
                                        return dueDate < today;
                                    });
                                    populateTable("alertsBody", overdueData, allowedRoles.includes(userRole), true);
                                }
                            } else {
                                console.error("Error fetching maintenance data:", data.message);
                                alert("Failed to load maintenance data: " + data.message);
                            }
                        })
                        .catch(error => {
                            console.error("Fetch error:", error);
                            alert("Error fetching maintenance data: " + error.message);
                        });
                } else {
                    throw new Error(data.message || "Update failed");
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("Error updating maintenance: " + error.message);
            });
    });
});

function fetchMaintenanceData() {
    // Fetch lab_id dynamically from a hidden input or session
    const labId = document.getElementById('labIdInput') ? document.getElementById('labIdInput').value : '';
    const payload = userRole === 'lab assistant' || userRole === 'lab faculty incharge' ? { lab_id: labId } : {};
    fetch("fetch_maintenance.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache"
        },
        body: JSON.stringify(payload)
    })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log('Fetch response:', data);
            if (data.status === "success") {
                window.maintenanceData = data.data || [];
                console.log('Fetched maintenance data:', window.maintenanceData);
                populateTable("maintenanceBody", window.maintenanceData, allowedRoles.includes(userRole));
            } else {
                console.error("Error fetching maintenance data:", data.message);
                alert("Failed to load maintenance data: " + data.message);
            }
        })
        .catch(error => {
            console.error("Fetch error:", error);
            alert("Error fetching maintenance data: " + error.message);
        });
}

function loadAlerts() {
    const today = new Date();
    const overdueData = (window.maintenanceData || []).filter(item => {
        const dueDate = new Date(item.maintenance_due);
        return dueDate < today && (item.disposal_status === null || item.disposal_status !== 'disposed completely');
    });
    document.getElementById("alertsTable").style.display = "block";
    populateTable("alertsBody", overdueData, allowedRoles.includes(userRole), true);
}

function populateTable(tbodyId, data, includeAction, isAlert = false) {
    const tbody = document.getElementById(tbodyId);
    tbody.innerHTML = "";

    if (!data || data.length === 0) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.colSpan = isAlert && allowedRoles.includes(userRole) ? 7 : isAlert ? 6 : allowedRoles.includes(userRole) ? 8 : 7;
        td.textContent = "No records found";
        td.style.textAlign = "center";
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
    }

    data.forEach((row) => {
        const tr = document.createElement("tr");

        if (!isAlert && allowedRoles.includes(userRole)) {
            const checkboxTd = document.createElement("td");
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "row-select";
            checkbox.dataset.srNo = row.sr_no;
            checkbox.dataset.labId = row.lab_id;
            checkbox.dataset.itemName = row.name_of_the_item;
            checkbox.dataset.date = row.date;
            checkbox.dataset.lastMaintenance = row.last_maintenance;
            checkbox.dataset.maintenanceDue = row.maintenance_due;
            checkbox.dataset.serviceProvider = row.service_provider;
            if (row.disposal_status !== null && row.disposal_status !== undefined) {
                checkbox.disabled = true;
                tr.classList.add("inactive-row");
            } else {
                checkbox.addEventListener("change", () => {
                    console.log('Checkbox changed:', checkbox.checked);
                    toggleDisposalButton();
                });
            }
            checkboxTd.appendChild(checkbox);
            tr.appendChild(checkboxTd);
        }

        const columns = [
            row.lab_id || "-",
            row.name_of_the_item || "-",
            row.date || "-",
            formatDate(row.last_maintenance),
            formatDate(row.maintenance_due),
            row.service_provider || "-"
        ];

        columns.forEach((val) => {
            const td = document.createElement("td");
            td.textContent = val;
            tr.appendChild(td);
        });

        if (allowedRoles.includes(userRole)) {
            const actionTd = document.createElement("td");
            const editBtn = document.createElement("button");
            editBtn.textContent = "Edit";
            editBtn.className = "edit-btn";
            editBtn.onclick = () => openModal(row, isAlert);
            actionTd.appendChild(editBtn);
            tr.appendChild(actionTd);
        }

        tbody.appendChild(tr);
    });
}

function formatDate(dateString) {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return isNaN(date) ? dateString : date.toISOString().split('T')[0];
}

function toggleDisposalButton() {
    const selectedItems = getSelectedItems();
    const disposalBtn = document.getElementById("sendDisposalRequest");
    console.log('Selected items:', selectedItems, 'userRole:', userRole);
    disposalBtn.style.display = allowedRoles.includes(userRole) && selectedItems.length > 0 ? "inline-block" : "none";
}

function getSelectedItems() {
    const checkboxes = document.querySelectorAll("#maintenanceBody input[type='checkbox']:checked:not(:disabled)");
    console.log('Selected checkboxes:', checkboxes);
    return Array.from(checkboxes).map(cb => ({
        sr_no: cb.dataset.srNo,
        lab_id: cb.dataset.labId,
        name_of_the_item: cb.dataset.itemName,
        date: cb.dataset.date,
        last_maintenance: cb.dataset.lastMaintenance,
        maintenance_due: cb.dataset.maintenanceDue,
        service_provider: cb.dataset.serviceProvider
    }));
}

function showDisposalReasonPopup(selectedItems) {
    const modal = document.getElementById('disposalReasonModal');
    modal.style.display = 'block';
    document.getElementById('disposalReason').value = '';
}

function openModal(row, isAlert = false) {
    const editSrNo = document.getElementById("editSrNo");
    const editItemId = document.getElementById("editItemId");
    const editLastMaintenance = document.getElementById("editLastMaintenance");
    const editMaintenanceDue = document.getElementById("editMaintenanceDue");
    const editServiceProvider = document.getElementById("editServiceProvider");

    editSrNo.value = row.sr_no || "";
    editItemId.value = row.name_of_the_item || "";
    editLastMaintenance.value = row.last_maintenance || "";
    editMaintenanceDue.value = row.maintenance_due || "";
    editServiceProvider.value = row.service_provider || "";
    document.getElementById("editModal").dataset.alert = isAlert;
    document.getElementById("editModal").style.display = "block";

    const newInput = editLastMaintenance.cloneNode(true);
    editLastMaintenance.parentNode.replaceChild(newInput, editLastMaintenance);

    newInput.addEventListener("change", function () {
        if (this.value) {
            const dueDate = new Date(this.value);
            dueDate.setFullYear(dueDate.getFullYear() + 10);
            document.getElementById("editMaintenanceDue").value = dueDate.toISOString().split('T')[0];
        } else {
            document.getElementById("editMaintenanceDue").value = "";
        }
    });
}

function closeModal() {
    document.getElementById("editModal").style.display = "none";
}

function closeDisposalModal() {
    document.getElementById("disposalReasonModal").style.display = "none";
    document.getElementById("disposalReason").value = "";
}