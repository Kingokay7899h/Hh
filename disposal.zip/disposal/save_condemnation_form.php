<?php
session_start();
ob_start();

// Ensure JSON content type
header('Content-Type: application/json');

// Function to send JSON response and exit
function sendResponse($status, $message)
{
    ob_end_clean();
    echo json_encode(['status' => $status, 'message' => $message]);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    error_log("save_condemnation_form.php - Unauthorized access: lab_id or role not set at " . date('Y-m-d H:i:s'));
    sendResponse('error', 'Unauthorized access. Please log in.');
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("save_condemnation_form.php - Invalid request method: " . $_SERVER['REQUEST_METHOD'] . " at " . date('Y-m-d H:i:s'));
    sendResponse('error', 'Invalid request method.');
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id']) || !isset($input['disposal_status'])) {
    error_log("save_condemnation_form.php - Invalid input data: id or disposal_status missing at " . date('Y-m-d H:i:s'));
    sendResponse('error', 'Invalid input data.');
}

// Ensure id is an integer
$id = isset($input['id']) ? (int)$input['id'] : 0;
$sr_no = isset($input['sr_no']) ? trim($input['sr_no']) : null;
$lab_id = isset($input['lab_id']) ? trim($input['lab_id']) : $_SESSION['lab_id'];
$disposal_status = trim($input['disposal_status']);

// Convert null or empty strings to empty strings for database compatibility
$prepared_by_name = isset($input['prepared_by_name']) ? trim($input['prepared_by_name']) : '';
$prepared_by_designation = isset($input['prepared_by_designation']) ? trim($input['prepared_by_designation']) : '';
$reviewed_by_name = isset($input['reviewed_by_name']) ? trim($input['reviewed_by_name']) : '';
$reviewed_by_designation = isset($input['reviewed_by_designation']) ? trim($input['reviewed_by_designation']) : '';
$committee_member2_name = isset($input['committee_member2_name']) ? trim($input['committee_member2_name']) : '';
$committee_member2_designation = isset($input['committee_member2_designation']) ? trim($input['committee_member2_designation']) : '';
$committee_member3_designation = isset($input['committee_member3_designation']) ? trim($input['committee_member3_designation']) : '';
$committee_member4_name = isset($input['committee_member4_name']) ? trim($input['committee_member4_name']) : '';
$committee_member5_name = isset($input['committee_member5_name']) ? trim($input['committee_member5_name']) : '';
$remarks = isset($input['remarks']) && trim($input['remarks']) !== '' ? trim($input['remarks']) : null;

// Log input for debugging
error_log("save_condemnation_form.php - Input: " . json_encode([
    'id' => $id,
    'sr_no' => $sr_no,
    'lab_id' => $lab_id,
    'disposal_status' => $disposal_status,
    'prepared_by_name' => $prepared_by_name,
    'prepared_by_designation' => $prepared_by_designation,
    'reviewed_by_name' => $reviewed_by_name,
    'reviewed_by_designation' => $reviewed_by_designation,
    'committee_member2_name' => $committee_member2_name,
    'committee_member2_designation' => $committee_member2_designation,
    'committee_member3_designation' => $committee_member3_designation,
    'committee_member4_name' => $committee_member4_name,
    'committee_member5_name' => $committee_member5_name,
    'remarks' => $remarks
], JSON_PRETTY_PRINT) . " at " . date('Y-m-d H:i:s'));

// Validate required fields
$missing_fields = [];
if ($id <= 0) $missing_fields[] = 'id';
if (!$disposal_status) $missing_fields[] = 'disposal_status';
if ($missing_fields) {
    error_log("save_condemnation_form.php - Missing required fields: " . implode(', ', $missing_fields) . " at " . date('Y-m-d H:i:s'));
    sendResponse('error', 'Missing required fields: ' . implode(', ', $missing_fields));
}

// Database connection
$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    error_log("save_condemnation_form.php - Database connection failed: " . $conn->connect_error . " (Error Code: " . $conn->connect_errno . ") at " . date('Y-m-d H:i:s'));
    sendResponse('error', 'Database connection failed: ' . $conn->connect_error);
}

$conn->begin_transaction();

try {
    // Verify table and column existence
    $result = $conn->query("SHOW COLUMNS FROM condemnation_records LIKE 'remarks'");
    if ($result->num_rows === 0) {
        throw new Exception('Remarks column does not exist in condemnation_records table.');
    }

    // Get sr_no and lab_id from condemnation_records if not provided
    if (empty($sr_no) || empty($lab_id)) {
        $stmt = $conn->prepare("SELECT sr_no, lab_id FROM condemnation_records WHERE id = ?");
        if (!$stmt) {
            throw new Exception('Prepare failed for condemnation_records select: ' . $conn->error);
        }
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            throw new Exception('No matching record found in condemnation_records for id: ' . $id);
        }
        $record = $result->fetch_assoc();
        $sr_no = $sr_no ?: $record['sr_no'];
        $lab_id = $lab_id ?: $record['lab_id'];
        $stmt->close();
    }

    // Check if condemnation_forms record exists
    $stmt = $conn->prepare("SELECT form_id FROM condemnation_forms WHERE form_id = ?");
    if (!$stmt) {
        throw new Exception('Prepare failed for condemnation_forms check: ' . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->num_rows > 0;
    $stmt->close();

    // Insert or update condemnation_forms
    if ($exists) {
        $sql = "UPDATE condemnation_forms SET 
                prepared_by_name = ?, prepared_by_designation = ?, 
                reviewed_by_name = ?, reviewed_by_designation = ?, 
                committee_member2_name = ?, committee_member2_designation = ?, 
                committee_member3_designation = ?, committee_member4_name = ?, 
                committee_member5_name = ?, created_at = NOW() 
                WHERE form_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception('Prepare failed for condemnation_forms update: ' . $conn->error);
        }
        error_log("save_condemnation_form.php - UPDATE condemnation_forms params: " . json_encode([
            'prepared_by_name' => $prepared_by_name,
            'prepared_by_designation' => $prepared_by_designation,
            'reviewed_by_name' => $reviewed_by_name,
            'reviewed_by_designation' => $reviewed_by_designation,
            'committee_member2_name' => $committee_member2_name,
            'committee_member2_designation' => $committee_member2_designation,
            'committee_member3_designation' => $committee_member3_designation,
            'committee_member4_name' => $committee_member4_name,
            'committee_member5_name' => $committee_member5_name,
            'form_id' => $id
        ], JSON_PRETTY_PRINT) . " at " . date('Y-m-d H:i:s'));
        $stmt->bind_param(
            "sssssssssi",
            $prepared_by_name,
            $prepared_by_designation,
            $reviewed_by_name,
            $reviewed_by_designation,
            $committee_member2_name,
            $committee_member2_designation,
            $committee_member3_designation,
            $committee_member4_name,
            $committee_member5_name,
            $id
        );
    } else {
        $sql = "INSERT INTO condemnation_forms (
                form_id, prepared_by_name, prepared_by_designation, 
                reviewed_by_name, reviewed_by_designation, 
                committee_member2_name, committee_member2_designation, 
                committee_member3_designation, committee_member4_name, 
                committee_member5_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception('Prepare failed for condemnation_forms insert: ' . $conn->error);
        }
        error_log("save_condemnation_form.php - INSERT condemnation_forms params: " . json_encode([
            'form_id' => $id,
            'prepared_by_name' => $prepared_by_name,
            'prepared_by_designation' => $prepared_by_designation,
            'reviewed_by_name' => $reviewed_by_name,
            'reviewed_by_designation' => $reviewed_by_designation,
            'committee_member2_name' => $committee_member2_name,
            'committee_member2_designation' => $committee_member2_designation,
            'committee_member3_designation' => $committee_member3_designation,
            'committee_member4_name' => $committee_member4_name,
            'committee_member5_name' => $committee_member5_name
        ], JSON_PRETTY_PRINT) . " at " . date('Y-m-d H:i:s'));
        $stmt->bind_param(
            "isssssssss",
            $id,
            $prepared_by_name,
            $prepared_by_designation,
            $reviewed_by_name,
            $reviewed_by_designation,
            $committee_member2_name,
            $committee_member2_designation,
            $committee_member3_designation,
            $committee_member4_name,
            $committee_member5_name
        );
    }
    if (!$stmt->execute()) {
        throw new Exception('Failed to save condemnation form: ' . $stmt->error);
    }
    $stmt->close();

    // Update remarks in condemnation_records
    if ($remarks !== null) {
        $stmt = $conn->prepare(
            "UPDATE condemnation_records SET remarks = ? WHERE sr_no = ? AND lab_id = ?"
        );
        if (!$stmt) {
            throw new Exception('Prepare failed for condemnation_records update: ' . $conn->error);
        }
        $stmt->bind_param("sss", $remarks, $sr_no, $lab_id);
        if (!$stmt->execute()) {
            throw new Exception('Failed to update condemnation_records: ' . $stmt->error);
        }
        $stmt->close();
    }

    // Update disposal_status in register table
    $result = $conn->query("SHOW TABLES LIKE 'register'");
    if ($result->num_rows > 0) {
        $stmt = $conn->prepare(
            "UPDATE register SET disposal_status = ? WHERE sr_no = ? AND lab_id = ?"
        );
        if (!$stmt) {
            throw new Exception('Prepare failed for register update: ' . $conn->error);
        }
        $stmt->bind_param("sss", $disposal_status, $sr_no, $lab_id);
        if (!$stmt->execute()) {
            throw new Exception('Failed to update register: ' . $stmt->error);
        }
        $stmt->close();
    }

    $conn->commit();
    error_log("save_condemnation_form.php - Successfully saved form for sr_no=$sr_no, lab_id=$lab_id, disposal_status=$disposal_status at " . date('Y-m-d H:i:s'));
    sendResponse('success', 'Form ' . ($disposal_status === 'Rejected by Stores' || $disposal_status === 'Rejected by Committee' ? 'rejected' : 'approved') . ' successfully');
} catch (Exception $e) {
    $conn->rollback();
    error_log("save_condemnation_form.php - Error: " . $e->getMessage() . " at " . date('Y-m-d H:i:s'));
    sendResponse('error', 'An error occurred: ' . $e->getMessage());
} finally {
    ob_end_clean();
    $conn->close();
}
?>