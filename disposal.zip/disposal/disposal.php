<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    header('Location: ../login/login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DAMS - Disposal</title>
    <link rel="stylesheet" href="./disposal.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <style>
        #disposalTable,
        #pastDisposalsTable,
        #rejectedDisposalsTable {
            width: 100%;
            border-collapse: collapse;
        }

        #disposalTable th,
        #disposalTable td,
        #pastDisposalsTable th,
        #pastDisposalsTable td,
        #rejectedDisposalsTable th,
        #rejectedDisposalsTable td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }

        #disposalTable th:nth-child(1),
        #disposalTable td:nth-child(1),
        #pastDisposalsTable th:nth-child(1),
        #pastDisposalsTable td:nth-child(1),
        #rejectedDisposalsTable th:nth-child(1),
        #rejectedDisposalsTable td:nth-child(1) {
            width: 5%;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            width: 50%;
        }

        .close {
            float: right;
            cursor: pointer;
        }

        .collapsible-content {
            display: none;
        }

        .collapsible-content.active {
            display: block;
        }

        .collapsible-title {
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .collapsible-title .chevron {
            transition: transform 0.3s ease;
        }

        .collapsible-title .chevron::before {
            content: '▼';
        }

        .collapsible-title.active .chevron::before {
            content: '▲';
        }
    </style>
    <script>
        const userRole = '<?php echo isset($_SESSION['role']) ? strtolower(trim($_SESSION['role'])) : ''; ?>';
        console.log('Session lab_id:', '<?php echo isset($_SESSION['lab_id']) ? htmlspecialchars($_SESSION['lab_id']) : 'unset'; ?>');
        console.log('Session role:', '<?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'unset'; ?>');
    </script>
    <input type="hidden" id="labIdInput" value="<?php echo isset($_SESSION['lab_id']) ? htmlspecialchars($_SESSION['lab_id']) : ''; ?>">
</head>

<body>
    <div id="dashboard-container" class="d-flex">

        <div id="sidebar" class="d-flex flex-column   py-3">
            <h4 class="dams ps-4 pt-4 mb-5"><b>DAMS</b></h4>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="lab_faculty_incharge.php" class="nav-link link-hover" id="dashboard-link"><i class="fas fa-home pe-2 ps-2"></i> Dashboard</a></li>
                <li><a href="../Inventory/category.php" class="nav-link link-hover" id="inventory-link"><i class="fas fa-box pe-2 ps-2"></i> Inventory</a></li>
                <li><a href="../forms/proc.html" class="nav-link link-hover" id="requisition-link"><i class="fas fa-file-alt pe-2 ps-2"></i> Procurement</a></li>
                <li><a href="../disposal/disposal.php" class="nav-link link-hover" id="condemnation-link"><i class="fas fa-exclamation-triangle pe-2 ps-2"></i> Codemnation</a></li>
                <li><a href="../maintenance/maintenance.php" class="nav-link link-hover" id="maintenance-link"><i class="fas fa-wrench pe-2 ps-2"></i> Maintenance</a></li>
                <li><a href="../Authetication/logout.php" class="nav-link link-hover"><i class="fas fa-sign-out-alt pe-2 ps-2"></i> Logout</a></li>
            </ul>
        </div>
        <!--  <div class="sidebar">
        <h2>DAMS</h2>
        <ul>
            <li><a href="../dashboard/dashboard.html">Dashboard</a></li>
            <li><a href="../inventory/inventory.html">Inventory</a></li>
            <li><a href="../procurement/procurement.html">Procurement</a></li>
            <li><a href="../disposal/disposal.php" class="active">Condemnation</a></li>
            <li><a href="../maintenance/maintenance.php">Maintenance</a></li>
            <li><a href="../student/student.html">Student Issues</a></li>
            <li><a href="../logout/logout.php">Logout</a></li>
        </ul>
    </div> -->
        <div id="main-content" class="container-fluid">
            <div class="row mynav d-flex">
                <nav class="navbar w-100 navbar-light bg-custom d-flex justify-content-between">
                    <span class="ms-3" id="menu-toggle"><i class="fas fa-bars"></i></span>
                    <input class="form-control w-50 ms-1" type="search" placeholder="Search assets...">
                    <div>
                        <i class="far fa-user"></i>
                        <span class="ms-1 me-3"><?php echo $_SESSION['name']; ?> (<?php echo $_SESSION['role']; ?>)</span>
                    </div>
                </nav>
            </div>

            <h1>Disposal Table</h1>
            <button id="disposeCompletelyBtn" style="display: none; margin-bottom: 10px; padding: 10px 20px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">Dispose Completely</button>
            <table id="disposalTable">
                <thead>
                    <tr>
                        <?php if (in_array(strtolower(trim($_SESSION['role'])), ['lab assistant', 'lab faculty incharge', 'hod', 'admin'])) { ?>
                            <th><input type="checkbox" id="selectAll"></th>
                        <?php } ?>
                        <th>Sr. No.</th>
                        <th>Lab ID</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Purchase Date</th>
                        <th>Condemnation Date</th>
                        <th>Reason for Condemnation</th>
                        <th>Disposal Status</th>
                        <th>View Form</th>
                    </tr>
                </thead>
                <tbody id="disposalBody"></tbody>
            </table>

            <div class="past-disposals">
                <h2 class="collapsible-title past-disposals-title" onclick="toggleCollapsible('pastDisposals')">
                    Past Disposals <span class="chevron"></span>
                </h2>
                <div id="pastDisposals" class="collapsible-content">
                    <table id="pastDisposalsTable">
                        <thead>
                            <tr>
                                <th>Sr. No.</th>
                                <th>Lab ID</th>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Purchase Date</th>
                                <th>Condemnation Date</th>
                                <th>Reason for Condemnation</th>
                                <th>Disposal Status</th>
                                <th>Remarks</th>
                                <th>View Form</th>
                            </tr>
                        </thead>
                        <tbody id="pastDisposalsBody"></tbody>
                    </table>
                </div>
            </div>

            <div class="rejected-disposals">
                <h2 class="collapsible-title rejected-disposals-title" onclick="toggleCollapsible('rejectedDisposals')">
                    Rejected Disposals <span class="chevron"></span>
                </h2>
                <div id="rejectedDisposals" class="collapsible-content">
                    <table id="rejectedDisposalsTable">
                        <thead>
                            <tr>
                                <th>Sr. No.</th>
                                <th>Lab ID</th>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Purchase Date</th>
                                <th>Condemnation Date</th>
                                <th>Reason for Condemnation</th>
                                <th>Disposal Status</th>
                                <th>Remarks</th>
                                <th>View Form</th>
                            </tr>
                        </thead>
                        <tbody id="rejectedDisposalsBody"></tbody>
                    </table>
                </div>
            </div>

            <div id="viewModal" class="modal">
                <div class="modal-content">
                    <span class="close" onclick="closeModal()">×</span>
                    <h2>View Disposal Info</h2>
                    <form id="viewForm">
                        <label>Serial Number: <input type="text" id="viewSrNo" disabled></label>
                        <label>Lab ID: <input type="text" id="viewLabId" disabled></label>
                        <label>Item Name: <input type="text" id="viewItemName" disabled></label>
                        <label>Quantity: <input type="text" id="viewQuantity" disabled></label>
                        <label>Price: <input type="text" id="viewPrice" disabled></label>
                        <label>Purchase Date: <input type="date" id="viewPurchaseDate" disabled></label>
                        <label>Condemnation Date: <input type="date" id="viewCondemnationDate" disabled></label>
                        <label>Reason for Condemnation: <textarea id="viewReasonForCondemnation" disabled></textarea></label>
                        <label>Disposal Status: <input type="text" id="viewDisposalStatus" disabled></label>
                        <button type="button" onclick="openCondemnationForm()">View Full Form</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <script src="disposal.js?v=13"></script>

</body>

</html>