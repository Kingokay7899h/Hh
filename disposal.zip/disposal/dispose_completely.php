<?php
session_start();
ob_start();
header('Content-Type: application/json');

if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    error_log("dispose_completely.php - Unauthorized access: lab_id or role not set at " . date('Y-m-d H:i:s'));
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$role = strtolower(trim($_SESSION['role']));
if (!in_array($role, ['lab assistant', 'lab faculty incharge', 'hod', 'admin'])) {
    error_log("dispose_completely.php - Unauthorized role: $role at " . date('Y-m-d H:i:s'));
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized role']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("dispose_completely.php - Invalid request method: " . $_SERVER['REQUEST_METHOD'] . " at " . date('Y-m-d H:i:s'));
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$items = $input['items'] ?? [];

if (empty($items)) {
    error_log("dispose_completely.php - No items provided at " . date('Y-m-d H:i:s'));
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'No items provided']);
    exit;
}

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    error_log("dispose_completely.php - Database connection failed: " . $conn->connect_error . " at " . date('Y-m-d H:i:s'));
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

$conn->begin_transaction();
try {
    $disposeTime = date('Y-m-d H:i:s');
    $stmtRegister = $conn->prepare("UPDATE register SET disposal_status = 'Disposed Completely' WHERE sr_no = ? AND lab_id = ?");
    if (!$stmtRegister) {
        throw new Exception("Prepare failed for register update: " . $conn->error);
    }

    $stmtCondemnation = $conn->prepare("UPDATE condemnation_records SET remarks = CONCAT(COALESCE(remarks, ''), '\nDisposed at $disposeTime') WHERE sr_no = ? AND lab_id = ?");
    if (!$stmtCondemnation) {
        throw new Exception("Prepare failed for condemnation_records update: " . $conn->error);
    }

    foreach ($items as $item) {
        $sr_no = $item['sr_no'] ?? '';
        $lab_id = $item['lab_id'] ?? '';
        if (empty($sr_no) || empty($lab_id)) {
            continue;
        }

        // Update register
        $stmtRegister->bind_param("ss", $sr_no, $lab_id);
        if (!$stmtRegister->execute()) {
            throw new Exception("Failed to update register: " . $stmtRegister->error);
        }

        // Update condemnation_records
        $stmtCondemnation->bind_param("ss", $sr_no, $lab_id);
        if (!$stmtCondemnation->execute()) {
            throw new Exception("Failed to update condemnation_records: " . $stmtCondemnation->error);
        }
    }

    $conn->commit();
    error_log("dispose_completely.php - Successfully disposed " . count($items) . " items at " . $disposeTime);
    ob_end_clean();
    echo json_encode(['status' => 'success', 'message' => 'Items disposed successfully']);
} catch (Exception $e) {
    $conn->rollback();
    error_log("dispose_completely.php - Error: " . $e->getMessage() . " at " . date('Y-m-d H:i:s'));
    ob_end_clean();
    echo json_encode(['status' => 'error', 'message' => 'Failed to dispose items: ' . $e->getMessage()]);
}

$stmtRegister->close();
$stmtCondemnation->close();
$conn->close();
