<?php
session_start();
$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["error" => "Invalid request method"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? null;

if (!$id) {
    echo json_encode(["error" => "Missing id"]);
    exit;
}

$sql = "SELECT prepared_by_name, prepared_by_designation, reviewed_by_name, reviewed_by_designation, 
        committee_member2_name, committee_member2_designation, committee_member3_designation, 
        committee_member4_name, committee_member5_name 
        FROM condemnation_forms WHERE form_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(["error" => "Query preparation failed"]);
    exit;
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc() ?: [];

echo json_encode($data);
$stmt->close();
$conn->close();
?>