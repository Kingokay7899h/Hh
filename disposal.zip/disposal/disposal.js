const allowedRoles = ['lab assistant', 'lab faculty incharge', 'hod', 'admin'];
document.addEventListener("DOMContentLoaded", function () {
    console.log('DOM loaded, userRole:', userRole);
    fetchDisposalData();

    if (allowedRoles.includes(userRole)) {
        // Handle selectAll checkbox
        const selectAllCheckbox = document.getElementById("selectAll");
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener("change", function () {
                const checkboxes = document.querySelectorAll("#disposalBody input[type='checkbox']:not(:disabled)");
                console.log('Select all checkboxes:', checkboxes.length);
                checkboxes.forEach(cb => cb.checked = this.checked);
                updateDisposeButton();
            });
        } else {
            console.warn("selectAll element not found in the DOM");
        }

        // Add change event listener to disposalTable for individual checkboxes
        const disposalTable = document.getElementById("disposalTable");
        if (disposalTable) {
            disposalTable.addEventListener("change", function (event) {
                if (event.target.classList.contains("row-select")) {
                    updateDisposeButton();
                }
            });
        } else {
            console.warn("disposalTable element not found in the DOM");
        }

        // Handle Dispose Completely button click
        const disposeBtn = document.getElementById("disposeCompletelyBtn");
        if (disposeBtn) {
            disposeBtn.addEventListener("click", function () {
                const selectedItems = Array.from(document.querySelectorAll("#disposalBody input.row-select:checked")).map(cb => ({
                    sr_no: cb.dataset.srNo,
                    lab_id: cb.dataset.labId
                }));

                if (selectedItems.length === 0) {
                    alert("No items selected.");
                    return;
                }

                // Create confirmation modal
                const modal = document.createElement("div");
                modal.id = "disposeModal";
                modal.style.cssText = `
                    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                    background-color: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;
                `;
                modal.innerHTML = `
                    <div style="background-color: white; padding: 20px; border-radius: 8px; max-width: 500px;">
                        <h2>Confirm Disposal</h2>
                        <p>Are you sure you want to dispose ${selectedItems.length} item(s) completely?</p>
                        <div style="text-align: right;">
                            <button id="confirmDispose" style="padding: 10px 20px; background-color: #28a745; color: white; border: none; border-radius: 5px; margin-right: 10px;">Confirm</button>
                            <button id="cancelDispose" style="padding: 10px 20px; background-color: #dc3545; color: white; border: none; border-radius: 5px;">Cancel</button>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);

                // Handle Confirm button
                document.getElementById("confirmDispose").addEventListener("click", function () {
                    fetch("dispose_completely.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ items: selectedItems })
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === "success") {
                                alert("Items disposed successfully!");
                                fetchDisposalData(); // Refresh tables
                                modal.remove();
                            } else {
                                alert("Error: " + data.message);
                            }
                        })
                        .catch(error => {
                            console.error("Error disposing items:", error);
                            alert("Error disposing items: " + error.message);
                        });
                });

                // Handle Cancel button
                document.getElementById("cancelDispose").addEventListener("click", function () {
                    modal.remove();
                });
            });
        } else {
            console.warn("disposeCompletelyBtn element not found in the DOM");
        }
    }
});

function fetchDisposalData() {
    const labId = document.getElementById('labIdInput') ? document.getElementById('labIdInput').value : '';
    const payload = ['lab assistant', 'lab faculty incharge'].includes(userRole) ? { lab_id: labId } : {};

    // Fetch Pending disposals (Pending Stores Approval or Pending Committee Approval)
    fetch("fetch_disposal.php", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" },
        body: JSON.stringify(payload)
    })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log('Fetch disposal response:', data);
            if (data.status === "success") {
                window.disposalData = data.data || [];
                console.log('Fetched disposal data:', window.disposalData);
                populateTable("disposalBody", window.disposalData, allowedRoles.includes(userRole));
            } else {
                console.error("Error fetching disposal data:", data.message);
                alert("Failed to load disposal data: " + data.message);
            }
        })
        .catch(error => {
            console.error("Fetch error for fetch_disposal.php:", error);
            alert("Error fetching disposal data: " + error.message);
        });

    // Fetch Past disposals (Approved by Committee)
    fetch("fetch_past_disposals.php", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" },
        body: JSON.stringify(payload)
    })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log('Fetch past disposal response:', data);
            if (data.status === "success") {
                window.pastDisposalData = data.data || [];
                console.log('Fetched past disposal data:', window.pastDisposalData);
                populateTable("pastDisposalsBody", window.pastDisposalData, allowedRoles.includes(userRole));
            } else {
                console.error("Error fetching past disposal data:", data.message);
                alert("Failed to load past disposal data: " + data.message);
            }
        })
        .catch(error => {
            console.error("Fetch error for fetch_past_disposals.php:", error);
            alert("Error fetching past disposal data: " + error.message);
        });

    // Fetch Rejected disposals (Rejected by Stores or Rejected by Committee)
    fetch("fetch_rejected_disposals.php", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" },
        body: JSON.stringify(payload)
    })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log('Fetch rejected disposal response:', data);
            if (data.status === "success") {
                window.rejectedDisposalData = data.data || [];
                console.log('Fetched rejected disposal data:', window.rejectedDisposalData);
                populateTable("rejectedDisposalsBody", window.rejectedDisposalData, allowedRoles.includes(userRole));
            } else {
                console.error("Error fetching rejected disposal data:", data.message);
                alert("Failed to load rejected disposal data: " + data.message);
            }
        })
        .catch(error => {
            console.error("Fetch error for fetch_rejected_disposals.php:", error);
            alert("Error fetching rejected disposal data: " + error.message);
        });
}

function toggleCollapsible(tableId) {
    const content = document.getElementById(tableId);
    const title = content.previousElementSibling;
    content.classList.toggle('active');
    title.classList.toggle('active');
}

function populateTable(tbodyId, data, includeCheckbox) {
    const tbody = document.getElementById(tbodyId);
    tbody.innerHTML = "";

    if (!data || data.length === 0) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");
        td.colSpan = tbodyId === "rejectedDisposalsBody" || tbodyId === "pastDisposalsBody" ? 11 : (allowedRoles.includes(userRole) ? 11 : 10); // Adjusted for Remarks column and role
        td.textContent = "No records found";
        td.style.textAlign = "center";
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
    }

    data.forEach((row, index) => {
        const tr = document.createElement("tr");

        if (tbodyId === "disposalBody" && allowedRoles.includes(userRole)) {
            const checkboxTd = document.createElement("td");
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "row-select";
            checkbox.dataset.srNo = row.sr_no;
            checkbox.dataset.labId = row.lab_id;
            checkbox.dataset.itemName = row.name_of_the_item || '-';
            checkbox.dataset.quantity = row.quantity || '-';
            checkbox.dataset.price = row.price || '-';
            checkbox.dataset.purchaseDate = row.purchase_date || '';
            checkbox.dataset.condemnationDate = row.condemnation_date || '';
            checkbox.dataset.reasonForCondemnation = row.reason_for_condemnation || '-';
            checkbox.dataset.disposalStatus = row.disposal_status || '-';
            checkbox.disabled = row.disposal_status !== 'Approved by Committee';
            checkboxTd.appendChild(checkbox);
            tr.appendChild(checkboxTd);
        }

        const columns = [
            row.sr_no || "-",
            row.lab_id || "-",
            row.name_of_the_item || "-",
            row.quantity || "-",
            row.price || "-",
            formatDate(row.purchase_date),
            formatDate(row.condemnation_date),
            row.reason_for_condemnation || "-",
            row.disposal_status || "-"
        ];

        if (tbodyId === "rejectedDisposalsBody" || tbodyId === "pastDisposalsBody") {
            columns.push(row.remarks || "-");
        }

        columns.forEach((val) => {
            const td = document.createElement("td");
            td.textContent = val;
            tr.appendChild(td);
        });

        const viewTd = document.createElement("td");
        const viewBtn = document.createElement("button");
        viewBtn.textContent = "View Form";
        viewBtn.className = "view-btn";
        viewBtn.onclick = () => viewForm(row);
        viewTd.appendChild(viewBtn);
        tr.appendChild(viewTd);

        tbody.appendChild(tr);
    });

    // Update Dispose Completely button visibility
    if (tbodyId === "disposalBody") {
        updateDisposeButton();
    }
}

function updateDisposeButton() {
    const disposeBtn = document.getElementById("disposeCompletelyBtn");
    const checkboxes = document.querySelectorAll("#disposalBody input.row-select:checked");
    disposeBtn.style.display = checkboxes.length > 0 ? "block" : "none";
}

function formatDate(dateString) {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return isNaN(date) ? dateString : date.toISOString().split('T')[0];
}

function viewForm(row) {
    console.log('View Form clicked for row:', JSON.stringify(row, null, 2));
    openCondemnationForm(row);
}

function openCondemnationForm(row) {
    const srNo = row.sr_no || '';
    const labId = row.lab_id || '';
    const disposalStatus = row.disposal_status || '';
    console.log('Opening condemnation form with sr_no:', srNo, 'lab_id:', labId, 'disposal_status:', disposalStatus, 'userRole:', userRole);
    if (srNo && labId) {
        window.open(`view_condemnation_form.html?sr_no=${encodeURIComponent(srNo)}&lab_id=${encodeURIComponent(labId)}&disposal_status=${encodeURIComponent(disposalStatus)}&user_role=${encodeURIComponent(userRole)}`, '_blank');
    } else {
        console.error('Cannot open form: Missing sr_no or lab_id', { srNo, labId });
        alert("Cannot open form: Missing serial number or lab ID");
    }
}

function closeModal() {
    document.getElementById("viewModal").style.display = "none";
}