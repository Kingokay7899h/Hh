<?php
session_start();
ob_start();

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    error_log("fetch_rejected_disposals.php - Database connection failed: " . $conn->connect_error);
    ob_end_clean();
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    error_log("fetch_rejected_disposals.php - Unauthorized access attempt: lab_id or role not set in session");
    ob_end_clean();
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("fetch_rejected_disposals.php - Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    ob_end_clean();
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$lab_id = $input['lab_id'] ?? null;
$role = strtolower(trim($_SESSION['role']));
error_log("fetch_rejected_disposals.php - Role: $role, Lab ID: " . ($lab_id ?? 'null'));

$sql = "SELECT cr.id, cr.sr_no, cr.lab_id, cr.name_of_the_item, cr.quantity, cr.price, cr.purchase_date, 
        cr.condemnation_date, cr.reason_for_condemnation, r.disposal_status, cr.remarks 
        FROM condemnation_records cr
        INNER JOIN register r ON cr.sr_no = r.sr_no AND cr.lab_id = r.lab_id
        WHERE r.disposal_status IN ('Rejected by Stores', 'Rejected by Committee')";
$params = [];
$types = "";

if ($role === 'lab assistant' || $role === 'lab faculty incharge') {
    if (!$lab_id) {
        error_log("fetch_rejected_disposals.php - Missing lab_id for role: $role");
        ob_end_clean();
        echo json_encode(["status" => "error", "message" => "Missing lab_id for role"]);
        exit;
    }
    $sql .= " AND cr.lab_id = ?";
    $params[] = $lab_id;
    $types .= "s";
}

error_log("fetch_rejected_disposals.php - SQL Query: $sql");
$stmt = $conn->prepare($sql);
if (!$stmt) {
    $error = $conn->error;
    error_log("fetch_rejected_disposals.php - Query preparation failed: $error");
    ob_end_clean();
    echo json_encode(["status" => "error", "message" => "Query preparation failed: $error"]);
    exit;
}

if (!empty($params)) {
    error_log("fetch_rejected_disposals.php - Binding parameters: " . json_encode($params));
    $stmt->bind_param($types, ...$params);
}

if (!$stmt->execute()) {
    $error = $stmt->error;
    error_log("fetch_rejected_disposals.php - Query execution failed: $error");
    $stmt->close();
    $conn->close();
    ob_end_clean();
    echo json_encode(["status" => "error", "message" => "Query execution failed: $error"]);
    exit;
}

$result = $stmt->get_result();
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

error_log("fetch_rejected_disposals.php - Fetched " . count($data) . " rows");
ob_end_clean();
echo json_encode(["status" => "success", "data" => $data]);

$stmt->close();
$conn->close();
?>