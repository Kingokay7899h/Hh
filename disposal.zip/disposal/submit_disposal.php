<?php
session_start();
header('Content-Type: application/json');
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    error_log('Unauthorized access in submit_disposal.php');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    error_log('Database connection failed: ' . $conn->connect_error);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

$items = json_decode($_POST['items'] ?? '[]', true);
$reason = $_POST['reason_for_disposal'] ?? '';

if (empty($items) || empty($reason)) {
    error_log('Missing required fields in submit_disposal.php');
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
    exit;
}

$conn->begin_transaction();
try {
    $sql = "UPDATE register SET reason_for_disposal = ?, disposal_status = 'Pending Stores' WHERE sr_no = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Query preparation failed: ' . $conn->error);
    }

    foreach ($items as $item) {
        $sr_no = $item['sr_no'] ?? '';
        if (empty($sr_no)) continue;
        $stmt->bind_param("ss", $reason, $sr_no);
        if (!$stmt->execute()) {
            throw new Exception('Query execution failed: ' . $stmt->error);
        }
    }

    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Disposal request submitted']);
} catch (Exception $e) {
    $conn->rollback();
    error_log('Submission failed in submit_disposal.php: ' . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Submission failed: ' . $e->getMessage()]);
}

$stmt->close();
$conn->close();
?>