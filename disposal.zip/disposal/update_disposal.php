<?php
session_start();
header('Content-Type: application/json');
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['lab_id']) || !isset($_SESSION['role'])) {
    error_log('Unauthorized access in update_disposal.php');
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$role = strtolower(trim($_SESSION['role']));
if (!in_array($role, ['hod', 'admin'])) {
    error_log('Unauthorized role for update_disposal.php: ' . $role);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized role']);
    exit;
}

$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    error_log('Database connection failed: ' . $conn->connect_error);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

$sr_no = $_POST['sr_no'] ?? '';
$lab_id = $_POST['lab_id'] ?? '';
$disposal_status = $_POST['disposal_status'] ?? '';

if (empty($sr_no) || empty($lab_id) || empty($disposal_status)) {
    error_log('Missing required fields in update_disposal.php - sr_no: ' . $sr_no . ', lab_id: ' . $lab_id . ', disposal_status: ' . $disposal_status);
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
    exit;
}

// Check if table exists
$sql_check = "SHOW TABLES LIKE 'register'";
$result_check = $conn->query($sql_check);
if ($result_check->num_rows === 0) {
    error_log('Table register does not exist');
    echo json_encode(['status' => 'error', 'message' => 'Table register does not exist']);
    exit;
}

// Format disposal_status with date
$formatted_status = $disposal_status === 'Approved' ? 'Approved on ' . date('Y-m-d') : ($disposal_status === 'Rejected' ? 'Rejected on ' . date('Y-m-d') : $disposal_status);

$conn->begin_transaction();
try {
    $sql = "UPDATE register SET disposal_status = ? WHERE sr_no = ? AND lab_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Query preparation failed: ' . $conn->error . ' | Query: ' . $sql);
    }
    $stmt->bind_param("sis", $formatted_status, $sr_no, $lab_id);
    if (!$stmt->execute()) {
        throw new Exception('Query execution failed: ' . $stmt->error);
    }
    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Disposal status updated']);
} catch (Exception $e) {
    $conn->rollback();
    error_log('Update failed in update_disposal.php: ' . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $e->getMessage()]);
}

$stmt->close();
$conn->close();
?>