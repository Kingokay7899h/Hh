<?php
session_start();
$conn = new mysqli("localhost", "root", "", "asset_management");
if ($conn->connect_error) {
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

if (!isset($_SESSION['lab_id'])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["error" => "Invalid request method"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$sr_no = $input['sr_no'] ?? null;
$lab_id = $input['lab_id'] ?? null;

if (!$sr_no || !$lab_id) {
    echo json_encode(["error" => "Missing sr_no or lab_id"]);
    exit;
}

// Updated query to include id
$sql = "SELECT id, sr_no, lab_id, name_of_the_item, quantity, price, purchase_date, condemnation_date, 
        period_of_use, `condition`, effort_for_repair_and_cost, location_of_items, 
        reason_for_condemnation, remarks 
        FROM condemnation_records WHERE sr_no = ? AND lab_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(["error" => "Query preparation failed"]);
    exit;
}

$stmt->bind_param("ss", $sr_no, $lab_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    echo json_encode(["error" => "No record found for sr_no: $sr_no and lab_id: $lab_id"]);
} else {
    echo json_encode($data);
}

$stmt->close();
$conn->close();
?>